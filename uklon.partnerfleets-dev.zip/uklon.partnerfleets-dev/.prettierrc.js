module.exports = {
  overrides: [
    {
      files: 'apps/ui/src/index.html',
      options: {
        parser: 'html',
      },
    },
  ],
  singleQuote: true,
};
