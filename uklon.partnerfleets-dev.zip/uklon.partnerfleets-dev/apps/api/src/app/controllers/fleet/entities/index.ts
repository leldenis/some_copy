export * from './fleet-details.entity';
export * from './fleet-history.entity';
