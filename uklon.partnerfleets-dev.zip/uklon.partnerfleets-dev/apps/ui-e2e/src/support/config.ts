export const DRIVERS = {
  images: {
    height: 156,
    width: 442,
  },
  imagesMobile: {
    height: 92,
    width: 183,
  },
  avatar: {
    avatarHeight: 56,
    avatarWidth: 56,
  },
};

export const VEHICLES = {
  images: {
    height: 156,
    width: 431,
  },
};
